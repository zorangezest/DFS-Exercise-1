ball.addEventListener("click", () => { index = (index + 1) % size.length;word.style.fontSize = sizes[index];
  
})